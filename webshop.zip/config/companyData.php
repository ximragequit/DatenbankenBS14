<?php
const COMPANY_NAME ="Company name";
const COMPANY_STREET ="Company test straße 1";
const COMPANY_ZIP ="1337";
const COMPANY_CITY = "Leet city";
