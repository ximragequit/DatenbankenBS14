<?php
define('DB_DATABASE','shop');
define('DB_USERNAME','shop');
define('DB_PASSWORD','123456');
define('DB_HOST','127.0.0.1');
define('DB_CHARSET','utf8');
