<?php
define('PAYPAL_CLIENT_ID','');
define('PAYPAL_SECRET','');
define('PAYPAL_BASE_URL','https://api.sandbox.paypal.com'); // live URL: https://api.paypal.com
