<?php require_once __DIR__.'/header.php'?>

<section class="container" id="selectDeliveryAdress">
  <?php require_once __DIR__.'/deliveryAddressList.php'?>
</section>

<section class="container" id="newDelieryAdress">
  <?php require_once __DIR__.'/deliveryAdressForm.php'?>
</section>



<?php require_once __DIR__.'/footer.php'?>
