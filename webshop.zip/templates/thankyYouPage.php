<?php require_once __DIR__.'/header.php'?>
<section class="container">
Vielen dank für Ihren Einkauf.
</section>
<?php require_once __DIR__.'/footer.php'?>
