<!DOCTYPE html>
<html lang="de">
<head>
  <title>BHH&ITECH</title>
  <base href="<?= $baseUrl ?>">
  <meta charset="utf-8">
  <link rel="stylesheet" href="assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body>
